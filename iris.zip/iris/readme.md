install the dependencies by

`pip install -r requirements.txt`

to run the code use 

`streamlit run main.py`